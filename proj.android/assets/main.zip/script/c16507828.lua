--ブラキオレイドス
function c16507828.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,94119974,38289717,true,true)
end
