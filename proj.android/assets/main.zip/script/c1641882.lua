--フュージョニスト
function c1641882.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,38142739,83464209,true,true)
end
