--裁きを下す女帝
function c15237615.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,5901497,64501875,true,true)
end
